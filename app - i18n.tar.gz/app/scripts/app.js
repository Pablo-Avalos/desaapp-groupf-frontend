'use strict';

/**
 * @ngdoc overview
 * @name desaappGroupfFrontendApp
 * @description
 * # desaappGroupfFrontendApp
 *
 * Main module of the application.
 */
angular
  .module('desaappGroupfFrontendApp', [
    'ngResource'
  ]);