app.config(function($translateProvider) {
$translateProvider.translations('es', {
HEADLINE: '¿Adonde vamos?',

})
.translations('en', {
HEADLINE: 'Where we go?',

});
$translateProvider.preferredLanguage('es');
});


app.controller('changeLanguageCtrl',function($translate,$scope){
	 
	 $scope.languge = "es";
	 console.log($scope.languge);
    $scope.changeLanguage= function(languge){
        $translate.use(languge);
        
    }
})